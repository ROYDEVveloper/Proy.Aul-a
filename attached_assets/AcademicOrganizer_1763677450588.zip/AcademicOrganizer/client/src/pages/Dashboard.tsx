import { DashboardStats } from "@/components/DashboardStats";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UserPlus, ClipboardList } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const stats = {
    totalAulas: 30,
    totalClases: 30,
    totalEstudiantes: 450,
    totalProgramas: 8,
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">
          Vista general del sistema de gestión académica
        </p>
      </div>

      <DashboardStats stats={stats} />

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Acciones Rápidas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Link href="/estudiantes">
              <Button className="w-full justify-start" data-testid="button-quick-registrar">
                <UserPlus className="mr-2 h-4 w-4" />
                Registrar Nuevo Estudiante
              </Button>
            </Link>
            <Link href="/notas">
              <Button variant="secondary" className="w-full justify-start" data-testid="button-quick-notas">
                <ClipboardList className="mr-2 h-4 w-4" />
                Ingresar Notas
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Información del Sistema</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Aulas disponibles:</span>
              <span className="font-mono font-medium">1001 - 1030</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Clases disponibles:</span>
              <span className="font-mono font-medium">1201 - 1230</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Semestres activos:</span>
              <span className="font-medium">1 - 10</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
