import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

interface DistributionChartProps {
  data: {
    rango: string;
    cantidad: number;
  }[];
}

export function DistributionChart({ data }: DistributionChartProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Distribución de Rendimiento</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis 
              dataKey="rango" 
              className="text-xs"
              stroke="hsl(var(--muted-foreground))"
              label={{ value: "Número de Estudiantes", position: "insideBottom", offset: -5 }}
            />
            <YAxis 
              className="text-xs"
              stroke="hsl(var(--muted-foreground))"
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "6px",
              }}
            />
            <Bar 
              dataKey="cantidad" 
              fill="hsl(var(--chart-3))"
              radius={[8, 8, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
