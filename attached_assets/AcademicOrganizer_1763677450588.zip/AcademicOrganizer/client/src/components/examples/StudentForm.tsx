import { StudentForm, StudentFormData } from '../StudentForm';

export default function StudentFormExample() {
  const mockProgramas = [
    { id: 1, nombre: "Ingeniería de Sistemas" },
    { id: 2, nombre: "Ingeniería Civil" },
    { id: 3, nombre: "Ingeniería Industrial" },
    { id: 4, nombre: "Administración de Empresas" },
    { id: 5, nombre: "Contaduría Pública" },
  ];

  const handleSubmit = (data: StudentFormData) => {
    console.log("Estudiante registrado:", data);
  };

  return <StudentForm programas={mockProgramas} onSubmit={handleSubmit} />;
}
