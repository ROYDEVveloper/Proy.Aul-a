import { Building2, BookOpen, Users, FileText } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface StatCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
}

function StatCard({ title, value, icon }: StatCardProps) {
  return (
    <Card data-testid={`card-stat-${title.toLowerCase()}`}>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <div className="text-muted-foreground">{icon}</div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold" data-testid={`text-${title.toLowerCase()}-count`}>{value}</div>
      </CardContent>
    </Card>
  );
}

interface DashboardStatsProps {
  stats: {
    totalAulas: number;
    totalClases: number;
    totalEstudiantes: number;
    totalProgramas: number;
  };
}

export function DashboardStats({ stats }: DashboardStatsProps) {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <StatCard
        title="Total Aulas"
        value={stats.totalAulas}
        icon={<Building2 className="h-4 w-4" />}
      />
      <StatCard
        title="Total Clases"
        value={stats.totalClases}
        icon={<BookOpen className="h-4 w-4" />}
      />
      <StatCard
        title="Total Estudiantes"
        value={stats.totalEstudiantes}
        icon={<Users className="h-4 w-4" />}
      />
      <StatCard
        title="Programas Académicos"
        value={stats.totalProgramas}
        icon={<FileText className="h-4 w-4" />}
      />
    </div>
  );
}
