import { db } from "./db";
import { eq, and } from "drizzle-orm";
import {
  type User,
  type InsertUser,
  type Programa,
  type InsertPrograma,
  type Aula,
  type InsertAula,
  type Clase,
  type InsertClase,
  type Estudiante,
  type InsertEstudiante,
  type Nota,
  type InsertNota,
  users,
  programas,
  aulas,
  clases,
  estudiantes,
  notas,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Programas
  getProgramas(): Promise<Programa[]>;
  getPrograma(id: number): Promise<Programa | undefined>;
  createPrograma(programa: InsertPrograma): Promise<Programa>;

  // Aulas
  getAulas(): Promise<Aula[]>;
  getAula(id: number): Promise<Aula | undefined>;
  createAula(aula: InsertAula): Promise<Aula>;

  // Clases
  getClases(): Promise<Clase[]>;
  getClase(id: number): Promise<Clase | undefined>;
  createClase(clase: InsertClase): Promise<Clase>;
  getClasesByPrograma(programaId: number): Promise<Clase[]>;
  getClasesBySemestre(semestreId: number): Promise<Clase[]>;
  getClasesByAula(aulaId: number): Promise<Clase[]>;

  // Estudiantes
  getEstudiantes(): Promise<Estudiante[]>;
  getEstudiante(id: number): Promise<Estudiante | undefined>;
  createEstudiante(estudiante: InsertEstudiante): Promise<Estudiante>;
  getEstudiantesByAula(aulaId: number): Promise<Estudiante[]>;
  getEstudiantesByPrograma(programaId: number): Promise<Estudiante[]>;
  getEstudiantesBySemestre(semestreId: number): Promise<Estudiante[]>;
  getEstudiantesByProgramaAndSemestre(programaId: number, semestreId: number): Promise<Estudiante[]>;

  // Notas
  getNotas(): Promise<Nota[]>;
  getNota(id: number): Promise<Nota | undefined>;
  createNota(nota: InsertNota): Promise<Nota>;
  getNotasByEstudiante(estudianteId: number): Promise<Nota[]>;
  getNotasByClase(claseId: number): Promise<Nota[]>;
  getNotasByCorte(corteId: number): Promise<Nota[]>;
  updateNota(id: number, nota: Partial<InsertNota>): Promise<Nota | undefined>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.query.users.findFirst({
      where: eq(users.id, id),
    });
    return result;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.query.users.findFirst({
      where: eq(users.username, username),
    });
    return result;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    await db.insert(users).values(user);
    return user;
  }

  // Programas
  async getProgramas(): Promise<Programa[]> {
    return await db.query.programas.findMany();
  }

  async getPrograma(id: number): Promise<Programa | undefined> {
    return await db.query.programas.findFirst({
      where: eq(programas.id_programa, id),
    });
  }

  async createPrograma(insertPrograma: InsertPrograma): Promise<Programa> {
    const result = await db
      .insert(programas)
      .values(insertPrograma)
      .returning();
    return result[0];
  }

  // Aulas
  async getAulas(): Promise<Aula[]> {
    return await db.query.aulas.findMany();
  }

  async getAula(id: number): Promise<Aula | undefined> {
    return await db.query.aulas.findFirst({
      where: eq(aulas.id_aula, id),
    });
  }

  async createAula(insertAula: InsertAula): Promise<Aula> {
    const result = await db
      .insert(aulas)
      .values(insertAula)
      .returning();
    return result[0];
  }

  // Clases
  async getClases(): Promise<Clase[]> {
    return await db.query.clases.findMany();
  }

  async getClase(id: number): Promise<Clase | undefined> {
    return await db.query.clases.findFirst({
      where: eq(clases.id_clase, id),
    });
  }

  async createClase(insertClase: InsertClase): Promise<Clase> {
    const result = await db
      .insert(clases)
      .values(insertClase)
      .returning();
    return result[0];
  }

  async getClasesByPrograma(programaId: number): Promise<Clase[]> {
    return await db.query.clases.findMany({
      where: eq(clases.programa_id, programaId),
    });
  }

  async getClasesBySemestre(semestreId: number): Promise<Clase[]> {
    return await db.query.clases.findMany({
      where: eq(clases.semestre_id, semestreId),
    });
  }

  async getClasesByAula(aulaId: number): Promise<Clase[]> {
    return await db.query.clases.findMany({
      where: eq(clases.aula_id, aulaId),
    });
  }

  // Estudiantes
  async getEstudiantes(): Promise<Estudiante[]> {
    return await db.query.estudiantes.findMany();
  }

  async getEstudiante(id: number): Promise<Estudiante | undefined> {
    return await db.query.estudiantes.findFirst({
      where: eq(estudiantes.id_estudiante, id),
    });
  }

  async createEstudiante(insertEstudiante: InsertEstudiante): Promise<Estudiante> {
    // Asignación automática de aula según programa
    let aulaId = insertEstudiante.aula_id;
    if (!aulaId && insertEstudiante.programa_id) {
      // Regla de asignación automática
      const programaAsignado = insertEstudiante.programa_id;
      const aulaAsignada = programaAsignado; // Aula = ID del programa
      aulaId = aulaAsignada;
    }

    const estudianteData: InsertEstudiante = {
      ...insertEstudiante,
      aula_id: aulaId,
    };

    const result = await db
      .insert(estudiantes)
      .values(estudianteData)
      .returning();
    return result[0];
  }

  async getEstudiantesByAula(aulaId: number): Promise<Estudiante[]> {
    return await db.query.estudiantes.findMany({
      where: eq(estudiantes.aula_id, aulaId),
    });
  }

  async getEstudiantesByPrograma(programaId: number): Promise<Estudiante[]> {
    return await db.query.estudiantes.findMany({
      where: eq(estudiantes.programa_id, programaId),
    });
  }

  async getEstudiantesBySemestre(semestreId: number): Promise<Estudiante[]> {
    return await db.query.estudiantes.findMany({
      where: eq(estudiantes.semestre_id, semestreId),
    });
  }

  async getEstudiantesByProgramaAndSemestre(
    programaId: number,
    semestreId: number
  ): Promise<Estudiante[]> {
    return await db.query.estudiantes.findMany({
      where: and(
        eq(estudiantes.programa_id, programaId),
        eq(estudiantes.semestre_id, semestreId)
      ),
    });
  }

  // Notas
  async getNotas(): Promise<Nota[]> {
    return await db.query.notas.findMany();
  }

  async getNota(id: number): Promise<Nota | undefined> {
    return await db.query.notas.findFirst({
      where: eq(notas.id_nota, id),
    });
  }

  async createNota(insertNota: InsertNota): Promise<Nota> {
    const result = await db
      .insert(notas)
      .values(insertNota)
      .returning();
    return result[0];
  }

  async getNotasByEstudiante(estudianteId: number): Promise<Nota[]> {
    return await db.query.notas.findMany({
      where: eq(notas.estudiante_id, estudianteId),
    });
  }

  async getNotasByClase(claseId: number): Promise<Nota[]> {
    return await db.query.notas.findMany({
      where: eq(notas.clase_id, claseId),
    });
  }

  async getNotasByCorte(corteId: number): Promise<Nota[]> {
    return await db.query.notas.findMany({
      where: eq(notas.corte_id, corteId),
    });
  }

  async updateNota(id: number, updateData: Partial<InsertNota>): Promise<Nota | undefined> {
    const result = await db
      .update(notas)
      .set(updateData)
      .where(eq(notas.id_nota, id))
      .returning();
    return result[0];
  }
}

export const storage = new DatabaseStorage();
