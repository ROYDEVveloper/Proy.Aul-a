import { GradesTable } from '../GradesTable';

export default function GradesTableExample() {
  const mockEstudiantes = [
    { id: 1, nombre: "Juan Pérez", nota1: 4.5, nota2: 4.2, nota3: 4.8, notaFinal: 4.5 },
    { id: 2, nombre: "María García", nota1: 3.8, nota2: 4.0, nota3: 3.5, notaFinal: 3.77 },
    { id: 3, nombre: "Carlos López", nota1: null, nota2: null, nota3: null, notaFinal: null },
    { id: 4, nombre: "Ana Martínez", nota1: 2.5, nota2: 3.0, nota3: 2.8, notaFinal: 2.77 },
  ];

  const handleSave = (estudianteId: number, notas: { nota1: number; nota2: number; nota3: number }) => {
    console.log("Guardando notas para estudiante", estudianteId, notas);
  };

  return <GradesTable clase="1201" estudiantes={mockEstudiantes} onSave={handleSave} />;
}
