import { DashboardStats } from '../DashboardStats';

export default function DashboardStatsExample() {
  const mockStats = {
    totalAulas: 30,
    totalClases: 30,
    totalEstudiantes: 450,
    totalProgramas: 8,
  };

  return <DashboardStats stats={mockStats} />;
}
