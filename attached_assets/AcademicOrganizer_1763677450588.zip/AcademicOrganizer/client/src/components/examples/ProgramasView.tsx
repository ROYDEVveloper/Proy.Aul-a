import { ProgramasView } from '../ProgramasView';

export default function ProgramasViewExample() {
  const mockProgramas = [
    {
      id: 1,
      nombre: "Ingeniería de Sistemas",
      estudiantes: [
        { id: 1, nombre: "Juan Pérez", semestre: 3, aula: "1001", clase: "1201" },
        { id: 2, nombre: "María García", semestre: 3, aula: "1001", clase: "1201" },
        { id: 3, nombre: "Carlos López", semestre: 5, aula: "1001", clase: "1201" },
        { id: 4, nombre: "Laura Sánchez", semestre: 7, aula: "1001", clase: "1201" },
      ],
    },
    {
      id: 2,
      nombre: "Ingeniería Civil",
      estudiantes: [
        { id: 5, nombre: "Ana Martínez", semestre: 4, aula: "1002", clase: "1202" },
        { id: 6, nombre: "Pedro Rodríguez", semestre: 6, aula: "1002", clase: "1202" },
        { id: 7, nombre: "Sofía Ramírez", semestre: 2, aula: "1002", clase: "1202" },
      ],
    },
    {
      id: 3,
      nombre: "Ingeniería Industrial",
      estudiantes: [
        { id: 8, nombre: "Diego Torres", semestre: 5, aula: "1003", clase: "1203" },
        { id: 9, nombre: "Valentina Cruz", semestre: 3, aula: "1003", clase: "1203" },
      ],
    },
  ];

  return <ProgramasView programas={mockProgramas} />;
}
