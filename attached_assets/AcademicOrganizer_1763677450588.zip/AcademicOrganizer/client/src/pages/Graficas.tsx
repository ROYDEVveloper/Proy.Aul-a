import { ChartsStats } from "@/components/ChartsStats";
import { TrendChart } from "@/components/TrendChart";
import { DistributionChart } from "@/components/DistributionChart";
import { ProgramsPieChart } from "@/components/ProgramsPieChart";

export default function Graficas() {
  // Mock data - todo: remove mock functionality
  const stats = {
    totalEstudiantes: 6,
    promedioGeneral: 4.03,
    tasaAprobacion: 100,
    programasActivos: 6,
  };

  const estudiantesData = [
    { nombre: "María", nota1: 4.5, nota2: 3.8, nota3: 4.2, notaFinal: 4.17 },
    { nombre: "Carlos", nota1: 3.5, nota2: 4.0, nota3: 3.8, notaFinal: 3.77 },
    { nombre: "Ana", nota1: 4.8, nota2: 4.5, nota3: 5.0, notaFinal: 4.77 },
    { nombre: "Jorge", nota1: 3.2, nota2: 3.0, nota3: 3.5, notaFinal: 3.23 },
    { nombre: "Laura", nota1: 4.5, nota2: 4.8, nota3: 4.5, notaFinal: 4.60 },
    { nombre: "Pedro", nota1: 4.2, nota2: 4.0, nota3: 4.5, notaFinal: 4.23 },
  ];

  const distribucionData = [
    { rango: "0.0 - 1.9", cantidad: 0 },
    { rango: "2.0 - 2.9", cantidad: 0 },
    { rango: "3.0 - 3.9", cantidad: 3 },
    { rango: "4.0 - 4.5", cantidad: 2 },
    { rango: "4.6 - 5.0", cantidad: 1 },
  ];

  const programasData = [
    { nombre: "Ingeniería de Sistemas", cantidad: 1, porcentaje: 17 },
    { nombre: "Administración de Empresas", cantidad: 1, porcentaje: 17 },
    { nombre: "Derecho", cantidad: 1, porcentaje: 17 },
    { nombre: "Ingeniería Civil", cantidad: 1, porcentaje: 17 },
    { nombre: "Medicina", cantidad: 1, porcentaje: 17 },
    { nombre: "Arquitectura", cantidad: 1, porcentaje: 17 },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Panel de Gráficas</h1>
        <p className="text-muted-foreground">
          Visualiza el rendimiento académico con gráficas interactivas
        </p>
      </div>

      <ChartsStats stats={stats} />

      <TrendChart data={estudiantesData} />

      <div className="grid gap-6 lg:grid-cols-2">
        <DistributionChart data={distribucionData} />
        <ProgramsPieChart data={programasData} />
      </div>
    </div>
  );
}
