import { AulasHierarchy } from '../AulasHierarchy';

export default function AulasHierarchyExample() {
  const mockAulas = [
    {
      id: 1,
      codigo: "1001",
      capacidad: 50,
      clases: [
        {
          id: 1,
          codigo: "1201",
          estudiantes: [
            { id: 1, nombre: "Juan Pérez", programa: "Ingeniería de Sistemas", semestre: 3 },
            { id: 2, nombre: "María García", programa: "Ingeniería de Sistemas", semestre: 3 },
            { id: 3, nombre: "Carlos López", programa: "Ingeniería de Sistemas", semestre: 5 },
          ],
        },
      ],
    },
    {
      id: 2,
      codigo: "1002",
      capacidad: 45,
      clases: [
        {
          id: 2,
          codigo: "1202",
          estudiantes: [
            { id: 4, nombre: "Ana Martínez", programa: "Ingeniería Civil", semestre: 4 },
            { id: 5, nombre: "Pedro Rodríguez", programa: "Ingeniería Civil", semestre: 6 },
          ],
        },
      ],
    },
  ];

  return <AulasHierarchy aulas={mockAulas} />;
}
