import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface StudentFormProps {
  programas: { id: number; nombre: string }[];
  onSubmit: (data: StudentFormData) => void;
}

export interface StudentFormData {
  nombre: string;
  programaId: number;
  semestre: number;
}

export function StudentForm({ programas, onSubmit }: StudentFormProps) {
  const [nombre, setNombre] = useState("");
  const [programaId, setProgramaId] = useState<string>("");
  const [semestre, setSemestre] = useState<string>("");

  const getAssignedAula = (programId: number) => {
    if (programId === 1) return "1001";
    if (programId === 2) return "1002";
    return `${1000 + programId}`;
  };

  const getAssignedClase = (programId: number) => {
    if (programId === 1) return "1201";
    if (programId === 2) return "1202";
    return `${1200 + programId}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (nombre && programaId && semestre) {
      onSubmit({
        nombre,
        programaId: parseInt(programaId),
        semestre: parseInt(semestre),
      });
      setNombre("");
      setProgramaId("");
      setSemestre("");
    }
  };

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Registrar Nuevo Estudiante</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="nombre">Nombre Completo</Label>
              <Input
                id="nombre"
                data-testid="input-nombre"
                placeholder="Ingrese el nombre del estudiante"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="programa">Programa Académico</Label>
              <Select value={programaId} onValueChange={setProgramaId} required>
                <SelectTrigger id="programa" data-testid="select-programa">
                  <SelectValue placeholder="Seleccione un programa" />
                </SelectTrigger>
                <SelectContent>
                  {programas.map((programa) => (
                    <SelectItem key={programa.id} value={programa.id.toString()}>
                      {programa.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="semestre">Semestre</Label>
              <Select value={semestre} onValueChange={setSemestre} required>
                <SelectTrigger id="semestre" data-testid="select-semestre">
                  <SelectValue placeholder="Seleccione el semestre" />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 10 }, (_, i) => i + 1).map((sem) => (
                    <SelectItem key={sem} value={sem.toString()}>
                      Semestre {sem}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button type="submit" className="w-full" data-testid="button-registrar">
              Registrar Estudiante
            </Button>
          </form>
        </CardContent>
      </Card>

      {programaId && semestre && (
        <Card>
          <CardHeader>
            <CardTitle>Asignación Automática</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground mb-2">
                Aula Asignada
              </p>
              <Badge variant="secondary" className="font-mono text-base" data-testid="badge-aula-asignada">
                Aula {getAssignedAula(parseInt(programaId))}
              </Badge>
            </div>

            <div>
              <p className="text-sm text-muted-foreground mb-2">
                Clase Asignada
              </p>
              <Badge variant="secondary" className="font-mono text-base" data-testid="badge-clase-asignada">
                Clase {getAssignedClase(parseInt(programaId))}
              </Badge>
            </div>

            <div className="pt-4 border-t">
              <p className="text-sm text-muted-foreground">
                El estudiante será asignado automáticamente según su programa académico.
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
