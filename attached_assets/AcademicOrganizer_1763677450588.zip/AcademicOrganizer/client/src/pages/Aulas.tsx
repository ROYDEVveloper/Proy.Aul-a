import { AulasHierarchy } from "@/components/AulasHierarchy";

export default function Aulas() {
  const mockAulas = [
    {
      id: 1,
      codigo: "1001",
      capacidad: 50,
      clases: [
        {
          id: 1,
          codigo: "1201",
          estudiantes: [
            { id: 1, nombre: "Juan Pérez García", programa: "Ingeniería de Sistemas", semestre: 3 },
            { id: 2, nombre: "María García López", programa: "Ingeniería de Sistemas", semestre: 3 },
            { id: 3, nombre: "Carlos López Martínez", programa: "Ingeniería de Sistemas", semestre: 5 },
            { id: 4, nombre: "Laura Sánchez Ruiz", programa: "Ingeniería de Sistemas", semestre: 7 },
          ],
        },
      ],
    },
    {
      id: 2,
      codigo: "1002",
      capacidad: 45,
      clases: [
        {
          id: 2,
          codigo: "1202",
          estudiantes: [
            { id: 5, nombre: "Ana Martínez Torres", programa: "Ingeniería Civil", semestre: 4 },
            { id: 6, nombre: "Pedro Rodríguez Gómez", programa: "Ingeniería Civil", semestre: 6 },
            { id: 7, nombre: "Sofía Ramírez Cruz", programa: "Ingeniería Civil", semestre: 2 },
          ],
        },
      ],
    },
    {
      id: 3,
      codigo: "1003",
      capacidad: 40,
      clases: [
        {
          id: 3,
          codigo: "1203",
          estudiantes: [
            { id: 8, nombre: "Diego Torres Hernández", programa: "Ingeniería Industrial", semestre: 5 },
            { id: 9, nombre: "Valentina Cruz Díaz", programa: "Ingeniería Industrial", semestre: 3 },
          ],
        },
      ],
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Vista por Aulas</h1>
        <p className="text-muted-foreground">
          Navegue por la jerarquía: Aulas → Clases → Estudiantes
        </p>
      </div>

      <AulasHierarchy aulas={mockAulas} />
    </div>
  );
}
