import { GradesTable } from "@/components/GradesTable";

export default function Notas() {
  const mockEstudiantes = [
    { id: 1, nombre: "Juan Pérez García", nota1: 4.5, nota2: 4.2, nota3: 4.8, notaFinal: 4.5 },
    { id: 2, nombre: "María García López", nota1: 3.8, nota2: 4.0, nota3: 3.5, notaFinal: 3.77 },
    { id: 3, nombre: "Carlos López Martínez", nota1: 4.0, nota2: 3.9, nota3: 4.1, notaFinal: 4.0 },
    { id: 4, nombre: "Laura Sánchez Ruiz", nota1: null, nota2: null, nota3: null, notaFinal: null },
    { id: 5, nombre: "Ana Martínez Torres", nota1: 2.5, nota2: 3.0, nota3: 2.8, notaFinal: 2.77 },
  ];

  const handleSave = (estudianteId: number, notas: { nota1: number; nota2: number; nota3: number }) => {
    console.log("Guardando notas para estudiante", estudianteId, notas);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Gestión de Notas</h1>
        <p className="text-muted-foreground">
          Ingrese y administre las calificaciones de los estudiantes
        </p>
      </div>

      <GradesTable clase="1201" estudiantes={mockEstudiantes} onSave={handleSave} />
    </div>
  );
}
