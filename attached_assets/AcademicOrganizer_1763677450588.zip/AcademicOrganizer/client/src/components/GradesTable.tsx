import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Save } from "lucide-react";

interface Estudiante {
  id: number;
  nombre: string;
  nota1: number | null;
  nota2: number | null;
  nota3: number | null;
  notaFinal: number | null;
}

interface GradesTableProps {
  clase: string;
  estudiantes: Estudiante[];
  onSave: (estudianteId: number, notas: { nota1: number; nota2: number; nota3: number }) => void;
}

export function GradesTable({ clase, estudiantes, onSave }: GradesTableProps) {
  const [editingGrades, setEditingGrades] = useState<Record<number, Partial<Estudiante>>>({});

  const handleGradeChange = (estudianteId: number, field: keyof Estudiante, value: string) => {
    const numValue = parseFloat(value);
    if (isNaN(numValue)) return;
    
    // Validar que la nota no sea superior a 5.0
    if (numValue > 5.0) {
      console.warn("La nota no puede ser superior a 5.0");
      return;
    }

    setEditingGrades({
      ...editingGrades,
      [estudianteId]: {
        ...editingGrades[estudianteId],
        [field]: numValue,
      },
    });
  };

  const calculateFinalGrade = (nota1: number | null, nota2: number | null, nota3: number | null) => {
    if (nota1 === null || nota2 === null || nota3 === null) return null;
    return ((nota1 + nota2 + nota3) / 3).toFixed(2);
  };

  const handleSave = (estudianteId: number) => {
    const grades = editingGrades[estudianteId];
    if (
      grades?.nota1 !== undefined && 
      grades?.nota2 !== undefined && 
      grades?.nota3 !== undefined &&
      typeof grades.nota1 === 'number' &&
      typeof grades.nota2 === 'number' &&
      typeof grades.nota3 === 'number'
    ) {
      onSave(estudianteId, {
        nota1: grades.nota1,
        nota2: grades.nota2,
        nota3: grades.nota3,
      });
      console.log(`Notas guardadas para estudiante ${estudianteId}:`, grades);
    }
  };

  const getGradeValue = (estudiante: Estudiante, field: keyof Estudiante) => {
    return editingGrades[estudiante.id]?.[field] ?? estudiante[field];
  };

  const getGradeBadgeVariant = (grade: number | null) => {
    if (grade === null) return "outline";
    if (grade >= 3.5) return "default";
    if (grade >= 3.0) return "secondary";
    return "destructive";
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Gestión de Notas - Clase {clase}</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Estudiante</TableHead>
              <TableHead className="text-center">Nota 1</TableHead>
              <TableHead className="text-center">Nota 2</TableHead>
              <TableHead className="text-center">Nota 3</TableHead>
              <TableHead className="text-center">Nota Final</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {estudiantes.map((estudiante) => {
              const nota1 = getGradeValue(estudiante, "nota1") as number | null;
              const nota2 = getGradeValue(estudiante, "nota2") as number | null;
              const nota3 = getGradeValue(estudiante, "nota3") as number | null;
              const notaFinal = calculateFinalGrade(nota1, nota2, nota3);

              return (
                <TableRow key={estudiante.id} data-testid={`row-estudiante-${estudiante.id}`}>
                  <TableCell className="font-medium">{estudiante.nombre}</TableCell>
                  <TableCell className="text-center">
                    <Input
                      type="number"
                      min="0"
                      max="5"
                      step="0.1"
                      className="w-20 mx-auto text-center"
                      value={nota1 ?? ""}
                      onChange={(e) => handleGradeChange(estudiante.id, "nota1", e.target.value)}
                      data-testid={`input-nota1-${estudiante.id}`}
                    />
                  </TableCell>
                  <TableCell className="text-center">
                    <Input
                      type="number"
                      min="0"
                      max="5"
                      step="0.1"
                      className="w-20 mx-auto text-center"
                      value={nota2 ?? ""}
                      onChange={(e) => handleGradeChange(estudiante.id, "nota2", e.target.value)}
                      data-testid={`input-nota2-${estudiante.id}`}
                    />
                  </TableCell>
                  <TableCell className="text-center">
                    <Input
                      type="number"
                      min="0"
                      max="5"
                      step="0.1"
                      className="w-20 mx-auto text-center"
                      value={nota3 ?? ""}
                      onChange={(e) => handleGradeChange(estudiante.id, "nota3", e.target.value)}
                      data-testid={`input-nota3-${estudiante.id}`}
                    />
                  </TableCell>
                  <TableCell className="text-center">
                    {notaFinal !== null ? (
                      <Badge variant={getGradeBadgeVariant(parseFloat(notaFinal))} data-testid={`badge-final-${estudiante.id}`}>
                        {notaFinal}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      size="sm"
                      onClick={() => handleSave(estudiante.id)}
                      data-testid={`button-save-${estudiante.id}`}
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Guardar
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
