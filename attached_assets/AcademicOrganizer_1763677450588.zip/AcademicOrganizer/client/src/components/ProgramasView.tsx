import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

interface Estudiante {
  id: number;
  nombre: string;
  semestre: number;
  aula: string;
  clase: string;
}

interface Programa {
  id: number;
  nombre: string;
  estudiantes: Estudiante[];
}

interface ProgramasViewProps {
  programas: Programa[];
}

export function ProgramasView({ programas }: ProgramasViewProps) {
  const [selectedSemestres, setSelectedSemestres] = useState<Record<number, string>>({});

  const getFilteredEstudiantes = (programaId: number, estudiantes: Estudiante[]) => {
    const semestre = selectedSemestres[programaId];
    if (!semestre || semestre === "todos") {
      return estudiantes;
    }
    return estudiantes.filter((e) => e.semestre.toString() === semestre);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Programas → Semestre → Estudiantes</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue={programas[0]?.id.toString()}>
          <TabsList className="flex flex-wrap h-auto">
            {programas.map((programa) => (
              <TabsTrigger
                key={programa.id}
                value={programa.id.toString()}
                data-testid={`tab-${programa.nombre.toLowerCase().replace(/\s+/g, '-')}`}
              >
                {programa.nombre}
              </TabsTrigger>
            ))}
          </TabsList>

          {programas.map((programa) => (
            <TabsContent key={programa.id} value={programa.id.toString()}>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <label className="text-sm font-medium">Filtrar por semestre:</label>
                  <Select
                    value={selectedSemestres[programa.id] || "todos"}
                    onValueChange={(value) =>
                      setSelectedSemestres({ ...selectedSemestres, [programa.id]: value })
                    }
                  >
                    <SelectTrigger className="w-48" data-testid={`select-semestre-${programa.id}`}>
                      <SelectValue placeholder="Todos los semestres" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos los semestres</SelectItem>
                      {Array.from({ length: 10 }, (_, i) => i + 1).map((sem) => (
                        <SelectItem key={sem} value={sem.toString()}>
                          Semestre {sem}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Semestre</TableHead>
                      <TableHead>Aula</TableHead>
                      <TableHead>Clase</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {getFilteredEstudiantes(programa.id, programa.estudiantes).map((estudiante) => (
                      <TableRow key={estudiante.id} data-testid={`row-estudiante-${estudiante.id}`}>
                        <TableCell className="font-medium">{estudiante.nombre}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{estudiante.semestre}</Badge>
                        </TableCell>
                        <TableCell>
                          <span className="font-mono text-sm">{estudiante.aula}</span>
                        </TableCell>
                        <TableCell>
                          <span className="font-mono text-sm">{estudiante.clase}</span>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                {getFilteredEstudiantes(programa.id, programa.estudiantes).length === 0 && (
                  <p className="text-center text-muted-foreground py-8">
                    No hay estudiantes en este semestre
                  </p>
                )}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
}
