import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Estudiante {
  id: number;
  nombre: string;
  programa: string;
  semestre: number;
}

interface Clase {
  id: number;
  codigo: string;
  estudiantes: Estudiante[];
}

interface Aula {
  id: number;
  codigo: string;
  capacidad: number;
  clases: Clase[];
}

interface AulasHierarchyProps {
  aulas: Aula[];
}

export function AulasHierarchy({ aulas }: AulasHierarchyProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Aulas → Clases → Estudiantes</CardTitle>
      </CardHeader>
      <CardContent>
        <Accordion type="multiple" className="w-full">
          {aulas.map((aula) => (
            <AccordionItem key={aula.id} value={`aula-${aula.id}`}>
              <AccordionTrigger data-testid={`trigger-aula-${aula.codigo}`}>
                <div className="flex items-center gap-4">
                  <span className="font-mono font-semibold">Aula {aula.codigo}</span>
                  <Badge variant="secondary">
                    Capacidad: {aula.capacidad}
                  </Badge>
                  <Badge variant="outline">
                    {aula.clases.reduce((sum, clase) => sum + clase.estudiantes.length, 0)} estudiantes
                  </Badge>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <Accordion type="multiple" className="pl-4">
                  {aula.clases.map((clase) => (
                    <AccordionItem key={clase.id} value={`clase-${clase.id}`}>
                      <AccordionTrigger data-testid={`trigger-clase-${clase.codigo}`}>
                        <div className="flex items-center gap-3">
                          <span className="font-mono">Clase {clase.codigo}</span>
                          <Badge variant="outline" className="text-xs">
                            {clase.estudiantes.length} estudiantes
                          </Badge>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Nombre</TableHead>
                              <TableHead>Programa</TableHead>
                              <TableHead>Semestre</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {clase.estudiantes.map((estudiante) => (
                              <TableRow key={estudiante.id} data-testid={`row-estudiante-${estudiante.id}`}>
                                <TableCell className="font-medium">
                                  {estudiante.nombre}
                                </TableCell>
                                <TableCell>{estudiante.programa}</TableCell>
                                <TableCell>
                                  <Badge variant="secondary">
                                    {estudiante.semestre}
                                  </Badge>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>
    </Card>
  );
}
