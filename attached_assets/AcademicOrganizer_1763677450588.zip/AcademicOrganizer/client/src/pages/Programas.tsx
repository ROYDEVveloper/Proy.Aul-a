import { ProgramasView } from "@/components/ProgramasView";

export default function Programas() {
  const mockProgramas = [
    {
      id: 1,
      nombre: "Ingeniería de Sistemas",
      estudiantes: [
        { id: 1, nombre: "Juan Pérez García", semestre: 3, aula: "1001", clase: "1201" },
        { id: 2, nombre: "María García López", semestre: 3, aula: "1001", clase: "1201" },
        { id: 3, nombre: "Carlos López Martínez", semestre: 5, aula: "1001", clase: "1201" },
        { id: 4, nombre: "Laura Sánchez Ruiz", semestre: 7, aula: "1001", clase: "1201" },
      ],
    },
    {
      id: 2,
      nombre: "Ingeniería Civil",
      estudiantes: [
        { id: 5, nombre: "Ana Martínez Torres", semestre: 4, aula: "1002", clase: "1202" },
        { id: 6, nombre: "Pedro Rodríguez Gómez", semestre: 6, aula: "1002", clase: "1202" },
        { id: 7, nombre: "Sofía Ramírez Cruz", semestre: 2, aula: "1002", clase: "1202" },
      ],
    },
    {
      id: 3,
      nombre: "Ingeniería Industrial",
      estudiantes: [
        { id: 8, nombre: "Diego Torres Hernández", semestre: 5, aula: "1003", clase: "1203" },
        { id: 9, nombre: "Valentina Cruz Díaz", semestre: 3, aula: "1003", clase: "1203" },
      ],
    },
    {
      id: 4,
      nombre: "Administración de Empresas",
      estudiantes: [
        { id: 10, nombre: "Roberto Jiménez Silva", semestre: 2, aula: "1004", clase: "1204" },
        { id: 11, nombre: "Camila Morales Vargas", semestre: 4, aula: "1004", clase: "1204" },
      ],
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Vista por Programas</h1>
        <p className="text-muted-foreground">
          Explore estudiantes organizados por Programa → Semestre
        </p>
      </div>

      <ProgramasView programas={mockProgramas} />
    </div>
  );
}
