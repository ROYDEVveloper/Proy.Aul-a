# Academic Grade Management System

## Overview

A web-based academic grade management platform for professors to organize and track student performance across classrooms (Aulas), classes (Clases), academic programs (Programas), and semesters. The system provides a hierarchical data structure for managing students, entering grades, and visualizing academic performance through interactive charts and statistics.

**Primary Purpose:** Streamline academic administration by providing professors with efficient tools for student registration, grade entry, and performance analytics organized by classrooms, programs, and semesters.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- **Framework:** React 18 with TypeScript
- **Routing:** Wouter (lightweight client-side routing)
- **UI Framework:** Shadcn/ui components built on Radix UI primitives
- **Styling:** Tailwind CSS with custom design system
- **State Management:** TanStack React Query for server state
- **Form Handling:** React Hook Form with Zod validation
- **Charts:** Recharts for data visualization

**Design System:**
- **Approach:** System-based design inspired by Linear, Notion, and Asana
- **Typography:** Inter font family with consistent heading hierarchy
- **Spacing:** Tailwind units (2, 4, 6, 8) for consistent layout
- **Theme Support:** Light/dark mode with CSS custom properties
- **Component Strategy:** Reusable UI components with variant-based styling using class-variance-authority

**Key Architectural Decisions:**
- **Component-based architecture** for modularity and reusability
- **File-based routing** through Wouter for simple navigation
- **Hierarchical data display** using accordions and nested tables for Aulas → Clases → Estudiantes relationships
- **Mock data approach** currently implemented in components (to be replaced with API calls)
- **Responsive design** with mobile-first approach using Tailwind breakpoints

### Backend Architecture

**Technology Stack:**
- **Runtime:** Node.js with TypeScript
- **Framework:** Express.js
- **Build Tool:** Vite for development and esbuild for production
- **Module System:** ES Modules

**Current State:**
- **Storage Layer:** In-memory storage implementation (MemStorage class)
- **Route Structure:** Placeholder API routes with `/api` prefix convention
- **Database Ready:** Drizzle ORM configured for PostgreSQL (schema defined but not yet connected)

**Architectural Patterns:**
- **Storage Interface Pattern:** IStorage interface allows swapping between in-memory and database implementations without changing route logic
- **Middleware Pipeline:** Express middleware for JSON parsing, logging, and request tracking
- **Development/Production Split:** Separate Vite dev server and production static serving

### Data Model

**Schema Structure (defined in shared/schema.ts):**
- **Users Table:** Basic authentication with username/password (PostgreSQL UUID primary keys)
- **Validation:** Drizzle-Zod integration for type-safe schema validation

**Domain Entities (currently mock data):**
- **Aulas (Classrooms):** Physical spaces with capacity
- **Clases (Classes):** Academic sessions within Aulas
- **Estudiantes (Students):** Linked to Programs and Semesters
- **Programas (Programs):** Academic programs (e.g., Engineering degrees)
- **Notas (Grades):** Three partial grades plus final grade calculation
- **Semesters:** Organizational structure for student progression

**Hierarchical Relationships:**
- Aulas contain multiple Clases
- Clases contain multiple Estudiantes
- Programas contain Estudiantes organized by Semester
- Each Estudiante has Notas for each Clase

### Key Features

**Student Management:**
- Student registration with automatic Aula/Clase assignment based on Program
- Organization by Program → Semester hierarchy
- Filtering capabilities by semester

**Grade Management:**
- Three partial grades (Nota 1, 2, 3) with automatic final grade calculation
- Grade validation (maximum 5.0 on Colombian scale)
- Inline editing with save functionality
- Visual status indicators (passing/failing)

**Analytics & Visualization:**
- Dashboard statistics (total students, classes, classrooms, programs)
- Performance distribution charts (grade range histograms)
- Student performance trends (line charts across grading periods)
- Program enrollment pie charts
- Quick action shortcuts for common tasks

**Navigation:**
- Sidebar navigation with icon-based menu
- Responsive mobile drawer for smaller screens
- Route-based active state indicators

## External Dependencies

### UI Component Libraries
- **Radix UI:** Headless component primitives for accessibility
  - Accordion, Dialog, Dropdown Menu, Select, Tabs, Toast, and 20+ other primitives
  - Provides keyboard navigation and ARIA compliance
- **Shadcn/ui:** Pre-styled component layer built on Radix UI
- **Lucide React:** Icon library for consistent iconography
- **Class Variance Authority:** Type-safe variant styling system

### Data & State Management
- **TanStack React Query:** Server state management with caching
- **React Hook Form:** Form state and validation
- **Zod:** Runtime type validation and schema definition
- **Drizzle Zod:** Bridge between Drizzle ORM and Zod validation

### Database & ORM
- **Drizzle ORM:** Type-safe SQL query builder
- **@neondatabase/serverless:** PostgreSQL driver for Neon database
  - Uses WebSocket connections via `ws` package
  - Configured but not yet actively used (mock data currently in use)
- **connect-pg-simple:** PostgreSQL session store (for future session management)

### Charting & Visualization
- **Recharts:** Declarative charting library built on D3
- **date-fns:** Date manipulation and formatting

### Development Tools
- **Vite:** Frontend build tool and dev server
- **esbuild:** Fast JavaScript bundler for production backend
- **tsx:** TypeScript execution for development
- **TypeScript:** Type safety across entire stack
- **Tailwind CSS:** Utility-first CSS framework with PostCSS

### Replit-Specific Integrations
- **@replit/vite-plugin-runtime-error-modal:** Development error overlay
- **@replit/vite-plugin-cartographer:** Code navigation tools
- **@replit/vite-plugin-dev-banner:** Development mode indicator

### Notes on Architecture
- **Database Provisioning:** Application expects `DATABASE_URL` environment variable for PostgreSQL connection
- **Session Management:** Infrastructure in place but not yet implemented
- **API Routes:** Placeholder structure ready for backend implementation
- **Mock Data Migration:** Current mock data in components should be replaced with API calls to backend routes using TanStack Query