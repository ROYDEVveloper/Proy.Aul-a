import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy } from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface EstudianteData {
  nombre: string;
  nota1: number;
  nota2: number;
  nota3: number;
  notaFinal: number;
}

interface TrendChartProps {
  data: EstudianteData[];
}

export function TrendChart({ data }: TrendChartProps) {
  if (data.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Tendencia de Calificaciones por Estudiante</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-[300px] text-muted-foreground">
            No hay datos disponibles para mostrar
          </div>
        </CardContent>
      </Card>
    );
  }

  const chartData = data.map((estudiante) => ({
    name: estudiante.nombre.split(' ')[0],
    "Nota 1": estudiante.nota1,
    "Nota 2": estudiante.nota2,
    "Nota 3": estudiante.nota3,
    "Nota Final": estudiante.notaFinal,
  }));

  const mejorEstudiante = data.reduce((prev, current) => 
    (current.notaFinal > prev.notaFinal) ? current : prev
  , data[0]);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-2">
          <CardTitle>Tendencia de Calificaciones por Estudiante</CardTitle>
          <Badge variant="default" className="gap-1" data-testid="badge-mejor-estudiante">
            <Trophy className="h-3 w-3" />
            Mejor: {mejorEstudiante.nombre} ({mejorEstudiante.notaFinal.toFixed(2)})
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis 
              dataKey="name" 
              className="text-xs"
              stroke="hsl(var(--muted-foreground))"
            />
            <YAxis 
              domain={[0, 5]} 
              className="text-xs"
              stroke="hsl(var(--muted-foreground))"
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "6px",
              }}
            />
            <Legend />
            <Line 
              type="monotone" 
              dataKey="Nota 1" 
              stroke="hsl(var(--chart-1))" 
              strokeWidth={2}
              dot={{ r: 4 }}
            />
            <Line 
              type="monotone" 
              dataKey="Nota 2" 
              stroke="hsl(var(--chart-2))" 
              strokeWidth={2}
              dot={{ r: 4 }}
            />
            <Line 
              type="monotone" 
              dataKey="Nota 3" 
              stroke="hsl(var(--chart-3))" 
              strokeWidth={2}
              dot={{ r: 4 }}
            />
            <Line 
              type="monotone" 
              dataKey="Nota Final" 
              stroke="hsl(var(--chart-4))" 
              strokeWidth={3}
              dot={{ r: 5 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
