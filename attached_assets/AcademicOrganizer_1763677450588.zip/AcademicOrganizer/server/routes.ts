import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertProgramaSchema,
  insertAulaSchema,
  insertClaseSchema,
  insertEstudianteSchema,
  insertNotaSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // PROGRAMAS
  app.get("/api/programas", async (req, res) => {
    try {
      const programas = await storage.getProgramas();
      res.json(programas);
    } catch (error) {
      res.status(500).json({ error: "Error fetching programas" });
    }
  });

  app.post("/api/programas", async (req, res) => {
    try {
      const validated = insertProgramaSchema.parse(req.body);
      const programa = await storage.createPrograma(validated);
      res.status(201).json(programa);
    } catch (error) {
      res.status(400).json({ error: "Invalid programa data" });
    }
  });

  // AULAS
  app.get("/api/aulas", async (req, res) => {
    try {
      const aulas = await storage.getAulas();
      res.json(aulas);
    } catch (error) {
      res.status(500).json({ error: "Error fetching aulas" });
    }
  });

  app.post("/api/aulas", async (req, res) => {
    try {
      const validated = insertAulaSchema.parse(req.body);
      const aula = await storage.createAula(validated);
      res.status(201).json(aula);
    } catch (error) {
      res.status(400).json({ error: "Invalid aula data" });
    }
  });

  // CLASES
  app.get("/api/clases", async (req, res) => {
    try {
      const { programa, semestre, aula } = req.query;
      let clases;
      
      if (programa) {
        clases = await storage.getClasesByPrograma(parseInt(programa as string));
      } else if (semestre) {
        clases = await storage.getClasesBySemestre(parseInt(semestre as string));
      } else if (aula) {
        clases = await storage.getClasesByAula(parseInt(aula as string));
      } else {
        clases = await storage.getClases();
      }
      res.json(clases);
    } catch (error) {
      res.status(500).json({ error: "Error fetching clases" });
    }
  });

  app.post("/api/clases", async (req, res) => {
    try {
      const validated = insertClaseSchema.parse(req.body);
      const clase = await storage.createClase(validated);
      res.status(201).json(clase);
    } catch (error) {
      res.status(400).json({ error: "Invalid clase data" });
    }
  });

  // ESTUDIANTES
  app.get("/api/estudiantes", async (req, res) => {
    try {
      const { programa, semestre, aula, clase } = req.query;
      let estudiantes;
      
      if (programa && semestre) {
        estudiantes = await storage.getEstudiantesByProgramaAndSemestre(
          parseInt(programa as string),
          parseInt(semestre as string)
        );
      } else if (programa) {
        estudiantes = await storage.getEstudiantesByPrograma(parseInt(programa as string));
      } else if (semestre) {
        estudiantes = await storage.getEstudiantesBySemestre(parseInt(semestre as string));
      } else if (aula) {
        estudiantes = await storage.getEstudiantesByAula(parseInt(aula as string));
      } else {
        estudiantes = await storage.getEstudiantes();
      }
      res.json(estudiantes);
    } catch (error) {
      res.status(500).json({ error: "Error fetching estudiantes" });
    }
  });

  app.post("/api/estudiantes", async (req, res) => {
    try {
      const validated = insertEstudianteSchema.parse(req.body);
      const estudiante = await storage.createEstudiante(validated);
      res.status(201).json(estudiante);
    } catch (error) {
      res.status(400).json({ error: "Invalid estudiante data" });
    }
  });

  // NOTAS
  app.get("/api/notas", async (req, res) => {
    try {
      const { estudiante, clase, corte } = req.query;
      let notas;
      
      if (estudiante) {
        notas = await storage.getNotasByEstudiante(parseInt(estudiante as string));
      } else if (clase) {
        notas = await storage.getNotasByClase(parseInt(clase as string));
      } else if (corte) {
        notas = await storage.getNotasByCorte(parseInt(corte as string));
      } else {
        notas = await storage.getNotas();
      }
      res.json(notas);
    } catch (error) {
      res.status(500).json({ error: "Error fetching notas" });
    }
  });

  app.post("/api/notas", async (req, res) => {
    try {
      const validated = insertNotaSchema.parse(req.body);
      const nota = await storage.createNota(validated);
      res.status(201).json(nota);
    } catch (error) {
      res.status(400).json({ error: "Invalid nota data" });
    }
  });

  app.patch("/api/notas/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validated = insertNotaSchema.partial().parse(req.body);
      const nota = await storage.updateNota(id, validated);
      if (!nota) {
        res.status(404).json({ error: "Nota not found" });
        return;
      }
      res.json(nota);
    } catch (error) {
      res.status(400).json({ error: "Invalid nota data" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
