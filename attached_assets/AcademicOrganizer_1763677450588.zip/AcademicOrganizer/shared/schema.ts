import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, smallint } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Tabla: usuarios (para autenticación)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Tabla: programas (Carreras)
export const programas = pgTable("programas", {
  id_programa: integer("id_programa").primaryKey().generatedAlwaysAsIdentity(),
  nombre_programa: varchar("nombre_programa", { length: 100 }).notNull(),
  codigo_programa: varchar("codigo_programa", { length: 20 }).notNull().unique(),
  estado: smallint("estado").default(1),
});

// Tabla: semestres
export const semestres = pgTable("semestres", {
  id_semestre: integer("id_semestre").primaryKey().generatedAlwaysAsIdentity(),
  numero_semestre: integer("numero_semestre").notNull(),
  descripcion: varchar("descripcion", { length: 50 }),
});

// Tabla: aulas
export const aulas = pgTable("aulas", {
  id_aula: integer("id_aula").primaryKey().generatedAlwaysAsIdentity(),
  codigo_aula: varchar("codigo_aula", { length: 20 }).notNull().unique(),
  capacidad: integer("capacidad").notNull(),
  estado: smallint("estado").default(1),
});

// Tabla: clases
export const clases = pgTable("clases", {
  id_clase: integer("id_clase").primaryKey().generatedAlwaysAsIdentity(),
  codigo_clase: varchar("codigo_clase", { length: 20 }).notNull().unique(),
  nombre_clase: varchar("nombre_clase", { length: 100 }).notNull(),
  aula_id: integer("aula_id").references(() => aulas.id_aula),
  semestre_id: integer("semestre_id").references(() => semestres.id_semestre),
  programa_id: integer("programa_id").references(() => programas.id_programa),
});

// Tabla: estudiantes
export const estudiantes = pgTable("estudiantes", {
  id_estudiante: integer("id_estudiante").primaryKey().generatedAlwaysAsIdentity(),
  nombre: varchar("nombre", { length: 100 }).notNull(),
  documento: varchar("documento", { length: 30 }).notNull().unique(),
  correo: varchar("correo", { length: 150 }),
  programa_id: integer("programa_id").references(() => programas.id_programa).notNull(),
  semestre_id: integer("semestre_id").references(() => semestres.id_semestre).notNull(),
  aula_id: integer("aula_id").references(() => aulas.id_aula),
  estado: smallint("estado").default(1),
});

// Tabla: cortes_academicos
export const cortes_academicos = pgTable("cortes_academicos", {
  id_corte: integer("id_corte").primaryKey().generatedAlwaysAsIdentity(),
  nombre_corte: varchar("nombre_corte", { length: 50 }).notNull(),
  porcentaje: decimal("porcentaje", { precision: 5, scale: 2 }).notNull(),
});

// Tabla: notas
export const notas = pgTable("notas", {
  id_nota: integer("id_nota").primaryKey().generatedAlwaysAsIdentity(),
  estudiante_id: integer("estudiante_id").references(() => estudiantes.id_estudiante).notNull(),
  clase_id: integer("clase_id").references(() => clases.id_clase).notNull(),
  corte_id: integer("corte_id").references(() => cortes_academicos.id_corte).notNull(),
  nota: decimal("nota", { precision: 5, scale: 2 }).notNull(),
  fecha_registro: timestamp("fecha_registro").default(sql`CURRENT_TIMESTAMP`),
});

// Insert Schemas con validaciones
export const insertProgramaSchema = createInsertSchema(programas).pick({
  nombre_programa: true,
  codigo_programa: true,
  estado: true,
});

export const insertSemestreSchema = createInsertSchema(semestres).pick({
  numero_semestre: true,
  descripcion: true,
});

export const insertAulaSchema = createInsertSchema(aulas).pick({
  codigo_aula: true,
  capacidad: true,
  estado: true,
});

export const insertClaseSchema = createInsertSchema(clases).pick({
  codigo_clase: true,
  nombre_clase: true,
  aula_id: true,
  semestre_id: true,
  programa_id: true,
});

export const insertEstudianteSchema = createInsertSchema(estudiantes).pick({
  nombre: true,
  documento: true,
  correo: true,
  programa_id: true,
  semestre_id: true,
  aula_id: true,
  estado: true,
});

export const insertNotaSchema = createInsertSchema(notas).pick({
  estudiante_id: true,
  clase_id: true,
  corte_id: true,
  nota: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Types
export type Programa = typeof programas.$inferSelect;
export type InsertPrograma = z.infer<typeof insertProgramaSchema>;

export type Semestre = typeof semestres.$inferSelect;
export type InsertSemestre = z.infer<typeof insertSemestreSchema>;

export type Aula = typeof aulas.$inferSelect;
export type InsertAula = z.infer<typeof insertAulaSchema>;

export type Clase = typeof clases.$inferSelect;
export type InsertClase = z.infer<typeof insertClaseSchema>;

export type Estudiante = typeof estudiantes.$inferSelect;
export type InsertEstudiante = z.infer<typeof insertEstudianteSchema>;

export type Nota = typeof notas.$inferSelect;
export type InsertNota = z.infer<typeof insertNotaSchema>;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
