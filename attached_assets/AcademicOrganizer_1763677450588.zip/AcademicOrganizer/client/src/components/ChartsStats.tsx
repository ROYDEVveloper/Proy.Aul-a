import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, TrendingUp, Trophy, BookOpen } from "lucide-react";
import { ReactNode } from "react";

interface ChartsStatsProps {
  stats: {
    totalEstudiantes: number;
    promedioGeneral: number;
    tasaAprobacion: number;
    programasActivos: number;
  };
}

function StatCard({ 
  title, 
  value, 
  subtitle, 
  icon 
}: { 
  title: string; 
  value: string | number; 
  subtitle: string; 
  icon: ReactNode;
}) {
  return (
    <Card className="bg-card">
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className="text-muted-foreground">{icon}</div>
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold" data-testid={`stat-${title.toLowerCase().replace(/\s+/g, '-')}`}>
          {value}
        </div>
        <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
      </CardContent>
    </Card>
  );
}

export function ChartsStats({ stats }: ChartsStatsProps) {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <StatCard
        title="Total Estudiantes"
        value={stats.totalEstudiantes}
        subtitle="Registrados en el sistema"
        icon={<Users className="h-4 w-4" />}
      />
      <StatCard
        title="Promedio General"
        value={stats.promedioGeneral.toFixed(2)}
        subtitle="Nota promedio de todos"
        icon={<TrendingUp className="h-4 w-4" />}
      />
      <StatCard
        title="Tasa de Aprobación"
        value={`${stats.tasaAprobacion}%`}
        subtitle={`${Math.round(stats.totalEstudiantes * stats.tasaAprobacion / 100)} de ${stats.totalEstudiantes} aprobados`}
        icon={<Trophy className="h-4 w-4" />}
      />
      <StatCard
        title="Programas Activos"
        value={stats.programasActivos}
        subtitle="Diferentes programas"
        icon={<BookOpen className="h-4 w-4" />}
      />
    </div>
  );
}
