import { StudentForm, StudentFormData } from "@/components/StudentForm";

export default function Estudiantes() {
  const programas = [
    { id: 1, nombre: "Ingeniería de Sistemas" },
    { id: 2, nombre: "Ingeniería Civil" },
    { id: 3, nombre: "Ingeniería Industrial" },
    { id: 4, nombre: "Administración de Empresas" },
    { id: 5, nombre: "Contaduría Pública" },
    { id: 6, nombre: "Derecho" },
    { id: 7, nombre: "Medicina" },
    { id: 8, nombre: "Arquitectura" },
  ];

  const handleSubmit = (data: StudentFormData) => {
    console.log("Nuevo estudiante registrado:", data);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Gestión de Estudiantes</h1>
        <p className="text-muted-foreground">
          Registre nuevos estudiantes con asignación automática de aulas y clases
        </p>
      </div>

      <StudentForm programas={programas} onSubmit={handleSubmit} />
    </div>
  );
}
